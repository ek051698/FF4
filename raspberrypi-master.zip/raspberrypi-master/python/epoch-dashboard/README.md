Simple dashboard using epoch [1] real time graphs. Expects to find subdirectories with the obvious things in them. 

    static
      css
        bootstrap-slate.min.css
		bootstrap.min.css
		epoch.min.css
		font-awesome.css
      js
	    d3.min.js
		epoch.min.js
		jquery.min.js
		  

[1] http://fastly.github.io/epoch/
